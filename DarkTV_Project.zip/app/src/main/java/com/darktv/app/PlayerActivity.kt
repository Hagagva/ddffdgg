package com.darktv.app

import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private var streamUrl: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemUI()
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        val tvTitle = findViewById<TextView>(R.id.tvChannelTitle)
        val btnBack = findViewById<Button>(R.id.btnBack)
        val btnRetry = findViewById<Button>(R.id.btnRetry)

        streamUrl = intent.getStringExtra("STREAM_URL") ?: ""
        tvTitle.text = intent.getStringExtra("CHANNEL_NAME") ?: "DARK TV"

        btnBack.setOnClickListener { finish() }
        btnRetry.setOnClickListener {
            releasePlayer()
            initPlayer()
        }

        if (streamUrl.isEmpty()) {
            Toast.makeText(this, "رابط البث غير صالح", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @OptIn(UnstableApi::class)
    private fun initPlayer() {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0")

        val mediaSourceFactory = DefaultMediaSourceFactory(this)
            .setDataSourceFactory(httpFactory)

        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(mediaSourceFactory)
            .build().also { exo ->
                playerView.player = exo
                exo.setMediaItem(MediaItem.fromUri(streamUrl))
                exo.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        Toast.makeText(
                            this@PlayerActivity,
                            "تعذر تشغيل القناة، اضغط إعادة أو جرب قناة أخرى",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                })
                exo.prepare()
                exo.playWhenReady = true
            }
    }

    private fun releasePlayer() {
        player?.release()
        player = null
    }

    private fun hideSystemUI() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
        )
    }

    override fun onStart() {
        super.onStart()
        if (player == null && streamUrl.isNotEmpty()) {
            initPlayer()
        }
    }

    override fun onStop() {
        super.onStop()
        releasePlayer()
    }
}
