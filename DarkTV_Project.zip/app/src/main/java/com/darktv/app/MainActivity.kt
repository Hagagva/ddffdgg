package com.darktv.app

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

data class Channel(
    val name: String,
    val url: String,
    val logo: String = "",
    val group: String = "عامة"
)

class MainActivity : AppCompatActivity() {

    private val defaultM3uUrl = "https://iptv-org.github.io/iptv/languages/ara.m3u"
    private val prefs by lazy { getSharedPreferences("dark_tv_prefs", Context.MODE_PRIVATE) }

    private val allChannels = mutableListOf<Channel>()
    private val filteredChannels = mutableListOf<Channel>()
    private var favorites = mutableSetOf<String>()
    private var selectedCategory = "الكل"
    private var searchQuery = ""

    private lateinit var rvChannels: RecyclerView
    private lateinit var tvStatus: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var categoriesContainer: LinearLayout
    private lateinit var adapter: ChannelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvChannels = findViewById(R.id.rvChannels)
        tvStatus = findViewById(R.id.tvStatus)
        progressBar = findViewById(R.id.progressBar)
        categoriesContainer = findViewById(R.id.categoriesContainer)

        favorites = prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()

        rvChannels.layoutManager = GridLayoutManager(this, 2)
        adapter = ChannelAdapter(
            items = filteredChannels,
            isFavorite = { favorites.contains(it.url) },
            onClick = { channel ->
                val intent = Intent(this, PlayerActivity::class.java)
                intent.putExtra("STREAM_URL", channel.url)
                intent.putExtra("CHANNEL_NAME", channel.name)
                startActivity(intent)
            },
            onToggleFav = { channel ->
                if (favorites.contains(channel.url)) {
                    favorites.remove(channel.url)
                } else {
                    favorites.add(channel.url)
                }
                prefs.edit().putStringSet("favorites", favorites).apply()
                applyFilters()
            }
        )
        rvChannels.adapter = adapter

        findViewById<Button>(R.id.btnRefresh).setOnClickListener { loadM3uChannels() }
        findViewById<Button>(R.id.btnAddM3u).setOnClickListener { showManageDialog() }

        findViewById<EditText>(R.id.etSearch).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString()?.trim() ?: ""
                applyFilters()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        loadM3uChannels()
    }

    private fun getSavedM3uUrl(): String {
        return prefs.getString("m3u_url", defaultM3uUrl) ?: defaultM3uUrl
    }

    private fun getManualChannels(): List<Channel> {
        val list = mutableListOf<Channel>()
        val raw = prefs.getString("manual_channels", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    Channel(
                        name = obj.optString("name", "قناة"),
                        url = obj.optString("url", ""),
                        logo = obj.optString("logo", ""),
                        group = obj.optString("group", "مضافة يدوياً")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun saveManualChannel(channel: Channel) {
        val arr = try {
            JSONArray(prefs.getString("manual_channels", "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        val obj = JSONObject().apply {
            put("name", channel.name)
            put("url", channel.url)
            put("logo", channel.logo)
            put("group", channel.group)
        }
        arr.put(obj)
        prefs.edit().putString("manual_channels", arr.toString()).apply()
    }

    private fun showManageDialog() {
        val options = arrayOf(
            "تغيير رابط قائمة M3U",
            "إضافة قناة فردية (m3u8)",
            "استعادة الرابط الافتراضي"
        )
        AlertDialog.Builder(this)
            .setTitle("إدارة القنوات")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showM3uUrlDialog()
                    1 -> showAddChannelDialog()
                    2 -> {
                        prefs.edit().putString("m3u_url", defaultM3uUrl).apply()
                        loadM3uChannels()
                    }
                }
            }
            .show()
    }

    private fun showM3uUrlDialog() {
        val input = EditText(this).apply {
            setText(getSavedM3uUrl())
            hint = "https://example.com/channels.m3u"
            setTextColor(Color.WHITE)
            setPadding(36, 28, 36, 28)
        }
        AlertDialog.Builder(this)
            .setTitle("رابط قائمة M3U")
            .setView(input)
            .setPositiveButton("حفظ وتحميل") { _, _ ->
                val url = input.text.toString().trim()
                if (url.startsWith("http")) {
                    prefs.edit().putString("m3u_url", url).apply()
                    loadM3uChannels()
                } else {
                    Toast.makeText(this, "أدخل رابطاً صحيحاً يبدأ بـ http", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showAddChannelDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 24, 36, 12)
        }
        val etName = EditText(this).apply { hint = "اسم القناة" }
        val etUrl = EditText(this).apply { hint = "رابط البث (.m3u8)" }
        val etGroup = EditText(this).apply { hint = "القسم (مثلاً: رياضة)" }
        layout.addView(etName)
        layout.addView(etUrl)
        layout.addView(etGroup)

        AlertDialog.Builder(this)
            .setTitle("إضافة قناة جديدة")
            .setView(layout)
            .setPositiveButton("إضافة") { _, _ ->
                val name = etName.text.toString().trim()
                val url = etUrl.text.toString().trim()
                val group = etGroup.text.toString().trim().ifEmpty { "مضافة يدوياً" }
                if (name.isNotEmpty() && url.startsWith("http")) {
                    val ch = Channel(name = name, url = url, group = group)
                    saveManualChannel(ch)
                    allChannels.add(0, ch)
                    buildCategoryChips()
                    applyFilters()
                    Toast.makeText(this, "تمت إضافة القناة", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "تأكد من الاسم والرابط", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun loadM3uChannels() {
        progressBar.visibility = View.VISIBLE
        tvStatus.text = "جاري جلب القنوات من السيرفر..."
        val urlStr = getSavedM3uUrl()

        thread {
            val loaded = mutableListOf<Channel>()
            loaded.addAll(getManualChannels())
            var errorMsg: String? = null

            try {
                val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 15000
                    readTimeout = 20000
                    setRequestProperty("User-Agent", "Mozilla/5.0")
                }
                val content = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()

                val lines = content.lines()
                var currentName = "قناة"
                var currentLogo = ""
                var currentGroup = "عامة"

                val logoRegex = Regex("tvg-logo=\"([^\"]*)\"")
                val groupRegex = Regex("group-title=\"([^\"]*)\"")

                for (rawLine in lines) {
                    val line = rawLine.trim()
                    if (line.startsWith("#EXTINF", ignoreCase = true)) {
                        currentLogo = logoRegex.find(line)?.groupValues?.get(1) ?: ""
                        currentGroup = groupRegex.find(line)?.groupValues?.get(1)?.ifEmpty { "عامة" } ?: "عامة"
                        currentName = line.substringAfterLast(",").trim().ifEmpty { "قناة" }
                    } else if (line.startsWith("http://") || line.startsWith("https://")) {
                        loaded.add(Channel(currentName, line, currentLogo, currentGroup))
                        currentName = "قناة"
                        currentLogo = ""
                        currentGroup = "عامة"
                    }
                }
            } catch (e: Exception) {
                errorMsg = e.message
            }

            runOnUiThread {
                progressBar.visibility = View.GONE
                allChannels.clear()
                allChannels.addAll(loaded)
                selectedCategory = "الكل"
                buildCategoryChips()
                applyFilters()

                if (errorMsg != null && loaded.isEmpty()) {
                    tvStatus.text = "تعذر تحميل القائمة: $errorMsg"
                } else {
                    tvStatus.text = "إجمالي القنوات: ${allChannels.size}"
                }
            }
        }
    }

    private fun buildCategoryChips() {
        categoriesContainer.removeAllViews()
        val categories = linkedSetOf("الكل", "المفضلة")
        allChannels.forEach { categories.add(it.group) }

        for (cat in categories.take(25)) {
            val chip = TextView(this).apply {
                text = cat
                textSize = 13f
                setTextColor(Color.WHITE)
                setPadding(36, 16, 36, 16)
                background = getDrawable(
                    if (cat == selectedCategory) R.drawable.bg_chip_active else R.drawable.bg_chip
                )
                val params = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(8, 0, 8, 0) }
                layoutParams = params
                setOnClickListener {
                    selectedCategory = cat
                    buildCategoryChips()
                    applyFilters()
                }
            }
            categoriesContainer.addView(chip)
        }
    }

    private fun applyFilters() {
        filteredChannels.clear()
        val q = searchQuery.lowercase()
        for (ch in allChannels) {
            val matchCat = when (selectedCategory) {
                "الكل" -> true
                "المفضلة" -> favorites.contains(ch.url)
                else -> ch.group == selectedCategory
            }
            val matchSearch = q.isEmpty() ||
                ch.name.lowercase().contains(q) ||
                ch.group.lowercase().contains(q)

            if (matchCat && matchSearch) {
                filteredChannels.add(ch)
            }
        }
        adapter.notifyDataSetChanged()
        tvStatus.text = "المعروض: ${filteredChannels.size} قناة"
    }
}

class ChannelAdapter(
    private val items: List<Channel>,
    private val isFavorite: (Channel) -> Boolean,
    private val onClick: (Channel) -> Unit,
    private val onToggleFav: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val ivLogo: ImageView = v.findViewById(R.id.ivLogo)
        val tvName: TextView = v.findViewById(R.id.tvName)
        val tvGroup: TextView = v.findViewById(R.id.tvGroup)
        val tvFav: TextView = v.findViewById(R.id.tvFav)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_channel, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvName.text = item.name
        holder.tvGroup.text = item.group

        val fav = isFavorite(item)
        holder.tvFav.text = if (fav) "★" else "☆"
        holder.tvFav.setTextColor(if (fav) Color.parseColor("#FFD700") else Color.parseColor("#888888"))

        if (item.logo.isNotEmpty()) {
            Glide.with(holder.itemView.context)
                .load(item.logo)
                .placeholder(R.drawable.ic_tv_placeholder)
                .error(R.drawable.ic_tv_placeholder)
                .into(holder.ivLogo)
        } else {
            holder.ivLogo.setImageResource(R.drawable.ic_tv_placeholder)
        }

        holder.itemView.setOnClickListener { onClick(item) }
        holder.tvFav.setOnClickListener { onToggleFav(item) }
    }

    override fun getItemCount(): Int = items.size
}
